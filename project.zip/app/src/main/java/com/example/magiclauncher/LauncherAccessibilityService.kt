package com.example.magiclauncher

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableSharedFlow

/** Optional: enables real-time recents, notification shade and lock-screen gestures. */
class LauncherAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) e.packageName?.toString()?.let { foreground.tryEmit(it) }
    }
    companion object {
        var instance: LauncherAccessibilityService? = null
        val foreground = MutableSharedFlow<String>(extraBufferCapacity = 16)
        fun openNotifications() = instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false
        fun lockScreen() = instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false

        /** Fallback when the service isn't enabled (needs EXPAND_STATUS_BAR permission). */
        @SuppressLint("WrongConstant")
        fun expandStatusBar(ctx: Context) = runCatching {
            val sb = ctx.getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        }
    }
}
