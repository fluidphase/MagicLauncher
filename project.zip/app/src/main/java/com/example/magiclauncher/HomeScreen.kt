package com.example.magiclauncher

import android.appwidget.AppWidgetProviderInfo
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.core.graphics.ColorUtils
import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

object WallpaperLoader {
    fun load(ctx: Context): ImageBitmap? = runCatching {
        val wm = WallpaperManager.getInstance(ctx)
        val d = wm.peekDrawable() ?: wm.drawable ?: return null
        val sc = min(1f, 2048f / max(d.intrinsicWidth, d.intrinsicHeight))
        d.toBitmap((d.intrinsicWidth * sc).toInt(), (d.intrinsicHeight * sc).toInt()).asImageBitmap()
    }.getOrNull()
}

private val bounce = spring<IntOffset>(Spring.DampingRatioLowBouncy, Spring.StiffnessLow)

@Composable
fun HomeScreen(vm: LauncherViewModel, onPickWidget: (AppWidgetProviderInfo) -> Unit) {
    val ctx = LocalContext.current; val view = LocalView.current
    val settings by vm.settings.collectAsState(); val items by vm.items.collectAsState()
    val pinned by vm.pinned.collectAsState(); val recents by vm.recents.collectAsState(); val allApps by vm.allApps.collectAsState()
    val edit by vm.editMode.collectAsState(); val drag by vm.drag.collectAsState(); val menu by vm.menu.collectAsState()
    val openFolderId by vm.openFolder.collectAsState(); val drawer by vm.drawerOpen.collectAsState()
    val settingsOpen by vm.settingsOpen.collectAsState(); val picker by vm.pickerOpen.collectAsState()
    val homeTick by vm.homeTick.collectAsState()
    val wallpaper = remember { WallpaperLoader.load(ctx) }
    val labelColor = remember(wallpaper) {
        wallpaper?.let { w ->
            val px = Bitmap.createScaledBitmap(w.asAndroidBitmap(), 1, 1, true).getPixel(0, 0)
            if (ColorUtils.calculateLuminance(px) > 0.5) Color(0xFF1C1C1E) else Color.White
        } ?: Color.White
    }

    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner) { owner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) { while (true) { vm.refreshRecents(); delay(4000) } } }

    val pageCount = (items.maxOfOrNull { it.cell.page } ?: 0) + 1 + if (edit) 1 else 0
    val pager = rememberPagerState { pageCount }
    LaunchedEffect(homeTick) { if (homeTick > 0) pager.animateScrollToPage(0, animationSpec = spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow)) }

    val overlay = openFolderId != null || drawer || settingsOpen || picker
    val blur by animateDpAsState(if (overlay) 24.dp else 0.dp, spring(stiffness = Spring.StiffnessLow), label = "blur")
    val launch: (AppRef, Rect) -> Unit = { r, b -> vm.closeOverlays(); launchApp(ctx, view, r, b) }
    BackHandler(overlay || edit || menu != null) { when { menu != null -> vm.menu.value = null; overlay -> vm.closeOverlays(); else -> vm.editMode.value = false } }

    CompositionLocalProvider(LocalLabelColor provides labelColor) {
    GestureContainer(
        enabled = !overlay && drag == null && menu == null,
        onSwipeDown = { if (!LauncherAccessibilityService.openNotifications()) LauncherAccessibilityService.expandStatusBar(ctx) },
        onSwipeUp = { vm.drawerOpen.value = true },
        onPinchIn = { vm.editMode.value = true },
        onDoubleTap = { LauncherAccessibilityService.lockScreen() },
        modifier = Modifier.fillMaxSize()
    ) {
        Box(Modifier.fillMaxSize()) {
            // Parallax wallpaper tied to page scroll
            wallpaper?.let {
                androidx.compose.foundation.Image(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize().graphicsLayer {
                    scaleX = 1.15f; scaleY = 1.15f
                    if (settings.parallax) translationX = -(pager.currentPage + pager.currentPageOffsetFraction) * size.width * 0.04f
                })
            }
            Box(Modifier.fillMaxSize().blur(blur)) {
                Workspace(vm, pager, settings, items, edit, drag)
                // page dots + small "Search" pill above the dock (as on the reference)
                Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 112.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(pageCount) { Box(Modifier.size(7.dp).clip(CircleShape).background(labelColor.copy(if (it == pager.currentPage) 0.9f else 0.35f))) }
                    }
                    Text("Search", color = labelColor, fontSize = 11.sp,
                        modifier = Modifier.clip(CircleShape).background(labelColor.copy(0.12f))
                            .clickable { vm.drawerOpen.value = true }.padding(horizontal = 16.dp, vertical = 4.dp))
                }
                DynamicDock(pinned, recents, settings, wallpaper, launch,
                    onLongPress = { r, b -> vm.menu.value = MenuState(null, r, b) }, modifier = Modifier.align(Alignment.BottomCenter))
                AnimatedVisibility(edit, Modifier.align(Alignment.TopCenter), enter = slideInVertically { -it } + fadeIn(), exit = slideOutVertically { -it } + fadeOut()) {
                    Row(Modifier.padding(top = 16.dp).clip(RoundedCornerShape(24.dp)).background(Color.Black.copy(0.5f)).padding(horizontal = 8.dp)) {
                        TextButton({ vm.pickerOpen.value = true }) { Text("Widgets") }
                        TextButton({ vm.settingsOpen.value = true }) { Text("Settings") }
                        TextButton({ vm.editMode.value = false }) { Text("Done") }
                    }
                }
            }
            // overlays
            CompositionLocalProvider(LocalLabelColor provides Color.White) {
            (items.firstOrNull { it.id == openFolderId } as? HomeItem.Folder)?.let { FolderOverlay(it, settings, launch) { vm.openFolder.value = null } }
            if (drawer) AppDrawer(allApps, settings, settings.swipeUp == SwipeUpAction.Search, launch) { vm.drawerOpen.value = false }
            if (picker) WidgetPicker(vm, onPickWidget) { vm.pickerOpen.value = false }
            if (settingsOpen) SettingsScreen(settings, { vm.updateSettings(it) }) { vm.settingsOpen.value = false }
            menu?.let { m -> ContextMenuLayer(m, vm, items.firstOrNull { it.id == m.itemId }) { vm.menu.value = null } }
            }
        }
    }
    }
}

@Composable
private fun Workspace(vm: LauncherViewModel, pager: PagerState, s: LauncherSettings, items: List<HomeItem>, edit: Boolean, drag: DragState?) {
    val density = LocalDensity.current; val view = LocalView.current; val scope = rememberCoroutineScope()
    val curItems by rememberUpdatedState(items); val curEdit by rememberUpdatedState(edit)
    val fling = PagerDefaults.flingBehavior(pager, snapAnimationSpec = spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow))

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val padL = with(density) { Metrics.padH.toPx() }; val padT = with(density) { Metrics.padTop.toPx() }
        val padB = with(density) { Metrics.padBottom.toPx() }
        val cellW = (constraints.maxWidth - 2 * padL) / s.columns; val cellH = (constraints.maxHeight - padT - padB) / s.rows
        val cellWDp = with(density) { cellW.toDp() }; val cellHDp = with(density) { cellH.toDp() }
        var pointer by remember { mutableStateOf(Offset.Zero) }; var grab by remember { mutableStateOf(Offset.Zero) }
        var start by remember { mutableStateOf(Offset.Zero) }; var lastFlip by remember { mutableLongStateOf(0L) }

        fun rectOf(i: HomeItem) = Rect(padL + i.cell.col * cellW, padT + i.cell.row * cellH,
            padL + (i.cell.col + i.spanX) * cellW, padT + (i.cell.row + i.spanY) * cellH)
        fun hit(p: Offset) = curItems.firstOrNull { it.cell.page == pager.currentPage && rectOf(it).contains(p) }

        Box(
            Modifier.fillMaxSize()
                .pointerInput(cellW, cellH, s.columns, s.rows) {
                    detectTapGestures(onTap = { p ->
                        val it = hit(p)
                        when {
                            it is HomeItem.App -> launchApp(view.context, view, it.ref, rectOf(it))
                            it is HomeItem.Folder && it.style == FolderStyle.Standard -> vm.openFolder.value = it.id
                            it == null && curEdit -> vm.editMode.value = false
                            else -> Unit
                        }
                    })
                }
                .pointerInput(cellW, cellH, s.columns, s.rows) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { p ->
                            view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)          // haptic on long-press
                            val it = hit(p)
                            if (it == null) vm.editMode.value = true else {
                                val r = rectOf(it); grab = p - r.topLeft; pointer = p; start = p
                                vm.beginDrag(it.id)
                                vm.menu.value = MenuState(it.id, (it as? HomeItem.App)?.ref, r)
                            }
                        },
                        onDrag = { ch, _ ->
                            ch.consume(); pointer = ch.position
                            if ((pointer - start).getDistance() > 24.dp.toPx()) vm.menu.value = null   // moving = drag, not menu
                            val tl = pointer - grab
                            vm.hover(Cell(pager.currentPage, ((tl.x - padL) / cellW).roundToInt(), ((tl.y - padT) / cellH).roundToInt()))
                            val now = System.currentTimeMillis(); val edge = 48.dp.toPx()
                            if (now - lastFlip > 700) {
                                if (pointer.x < edge && pager.currentPage > 0) { lastFlip = now; scope.launch { pager.animateScrollToPage(pager.currentPage - 1) } }
                                else if (pointer.x > size.width - edge && pager.currentPage < pager.pageCount - 1) { lastFlip = now; scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }
                            }
                        },
                        onDragEnd = { vm.drop() }, onDragCancel = { vm.drop() }
                    )
                }
        ) {
            HorizontalPager(pager, Modifier.fillMaxSize(), flingBehavior = fling, userScrollEnabled = drag == null, beyondViewportPageCount = 1) { page ->
                Box(Modifier.fillMaxSize().padding(start = Metrics.padH, end = Metrics.padH, top = Metrics.padTop, bottom = Metrics.padBottom)) {
                    items.filter { it.cell.page == page && it.id != drag?.id }.forEach { item ->
                        key(item.id) { GridItem(item, cellWDp, cellHDp, cellW, cellH, vm, s, edit) }
                    }
                    if (drag != null && drag.hover.page == page) items.firstOrNull { it.id == drag.id }?.let { di ->
                        Box(Modifier.offset(cellWDp * di.cell.col, cellHDp * di.cell.row).size(cellWDp * di.spanX, cellHDp * di.spanY)
                            .padding(4.dp).clip(RoundedCornerShape(24.dp)).background(Color.White.copy(0.18f)))
                    }
                }
            }
            // ghost under the finger
            drag?.let { d -> items.firstOrNull { it.id == d.id }?.let { di ->
                Box(Modifier.offset { IntOffset((pointer.x - grab.x).roundToInt(), (pointer.y - grab.y).roundToInt()) }
                    .size(cellWDp * di.spanX, cellHDp * di.spanY).padding(4.dp)
                    .graphicsLayer { scaleX = 1.1f; scaleY = 1.1f; alpha = 0.92f }) { ItemBody(di, vm, s) }
            } }
        }
    }
}

@Composable
private fun GridItem(item: HomeItem, cellW: Dp, cellH: Dp, cellWpx: Float, cellHpx: Float, vm: LauncherViewModel, s: LauncherSettings, edit: Boolean) {
    val density = LocalDensity.current
    val target = with(density) { IntOffset((cellW * item.cell.col).roundToPx(), (cellH * item.cell.row).roundToPx()) }
    val offset by animateIntOffsetAsState(target, bounce, label = "slide")          // items slide out of the way
    val w by animateDpAsState(cellW * item.spanX, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow), label = "w")
    val h by animateDpAsState(cellH * item.spanY, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow), label = "h")
    Box(Modifier.offset { offset }.size(w, h).padding(4.dp)) {
        ItemBody(item, vm, s)
        if (edit && (item is HomeItem.Widget || item is HomeItem.Stack)) {
            var acc by remember { mutableStateOf(Offset.Zero) }
            Box(Modifier.align(Alignment.BottomEnd).size(32.dp).clip(CircleShape).background(Color.White)
                .pointerInput(item.id) {                                              // free-form resize, magnetic snap to cells
                    detectDragGestures(onDragEnd = { acc = Offset.Zero }) { ch, d ->
                        ch.consume(); acc += d
                        val sx = (acc.x / cellWpx).roundToInt(); val sy = (acc.y / cellHpx).roundToInt()
                        if (sx != 0 || sy != 0) { vm.resizeBy(item.id, sx, sy); acc -= Offset(sx * cellWpx, sy * cellHpx) }
                    }
                })
        }
        if (edit) Box(Modifier.align(Alignment.TopEnd).size(24.dp).clip(CircleShape).background(Color(0xFFE53935)).clickable { vm.remove(item.id) },
            Alignment.Center) { Text("–", color = Color.White) }
    }
}

@Composable
private fun ItemBody(item: HomeItem, vm: LauncherViewModel, s: LauncherSettings) {
    val view = LocalView.current
    val launch: (AppRef, Rect) -> Unit = { r, b -> launchApp(view.context, view, r, b) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        when (item) {
            is HomeItem.App -> AppIcon(item.ref, s, (if (maxWidth < maxHeight) maxWidth else maxHeight) * 0.62f, Modifier.fillMaxSize())
            is HomeItem.Folder -> FolderCard(item, s, launch, { vm.openFolder.value = item.id }, Modifier.fillMaxSize())
            is HomeItem.Widget -> WidgetView(item, Modifier.fillMaxSize()) { vm.drawerOpen.value = true }
            is HomeItem.Stack -> WidgetStackView(item, Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun WidgetPicker(vm: LauncherViewModel, onPick: (AppWidgetProviderInfo) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val providers = remember { android.appwidget.AppWidgetManager.getInstance(ctx).installedProviders }
    AlertDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onDismiss) { Text("Close") } }, title = { Text("Add widget") }, text = {
        LazyColumn {
            items(WidgetKind.values().filter { it != WidgetKind.External }) { k ->
                Text("Magic ${k.name}", Modifier.fillMaxWidth().clickable { vm.addBuiltIn(k); onDismiss() }.padding(12.dp))
            }
            items(providers) { p ->
                Text(p.loadLabel(ctx.packageManager), Modifier.fillMaxWidth().clickable { onPick(p); onDismiss() }.padding(12.dp))
            }
        }
    })
}
