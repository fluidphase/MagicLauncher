package com.example.magiclauncher

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.dp

@Composable
fun AppDrawer(apps: List<AppRef>, settings: LauncherSettings, focusSearch: Boolean, onLaunch: (AppRef, Rect) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow)); if (focusSearch) runCatching { fr.requestFocus() } }
    val shown = remember(q, apps) { apps.filter { it.label.contains(q, ignoreCase = true) } }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(0.45f * p.value.coerceIn(0f, 1f))).noRippleClickable(onDismiss)) {
        Column(
            Modifier.align(Alignment.TopCenter).fillMaxWidth(0.7f).padding(top = 48.dp)
                .graphicsLayer { translationY = (1 - p.value) * 200f; alpha = p.value.coerceIn(0f, 1f) }.noRippleClickable { }
        ) {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().focusRequester(fr), singleLine = true,
                placeholder = { Text("Search apps") }, shape = CircleShape)
            LazyVerticalGrid(GridCells.Adaptive(96.dp), contentPadding = PaddingValues(top = 24.dp, bottom = 48.dp)) {
                items(shown, key = { it.pkg + it.cls }) { ref ->
                    var b by remember { mutableStateOf(Rect.Zero) }
                    AppIcon(ref, settings, 64.dp, Modifier.padding(8.dp).onGloballyPositioned { b = it.boundsInRoot() }.clickable { onLaunch(ref, b) })
                }
            }
        }
    }
}
