package com.example.magiclauncher

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(s: LauncherSettings, change: ((LauncherSettings) -> LauncherSettings) -> Unit, onClose: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = Color(0xF2101014)) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 96.dp, vertical = 40.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Launcher settings", style = MaterialTheme.typography.headlineSmall); TextButton(onClose) { Text("Done") } } }
            item { Head("Desktop grid") }
            item { Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GridPresets.forEach { (c, r) -> FilterChip(s.columns == c && s.rows == r, { change { it.copy(columns = c, rows = r) } }, { Text("$c×$r") }) } } }
            item { Slide("Columns ${s.columns}", s.columns.toFloat(), 3f..12f, 8) { v -> change { it.copy(columns = v.toInt()) } } }
            item { Slide("Rows ${s.rows}", s.rows.toFloat(), 3f..10f, 6) { v -> change { it.copy(rows = v.toInt()) } } }
            item { Head("Icons") }
            item { Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconShape.values().forEach { sh -> FilterChip(s.iconShape == sh, { change { it.copy(iconShape = sh) } }, { Text(sh.name) }) } } }
            item { Slide("Icon size ${(s.iconScale * 100).toInt()}%", s.iconScale, 0.8f..1.2f, 0) { v -> change { it.copy(iconScale = v) } } }
            item { Sw("Show labels", s.showLabels) { v -> change { it.copy(showLabels = v) } } }
            item { Head("Dock") }
            item { Sw("Dock blur", s.dockBlurEnabled) { v -> change { it.copy(dockBlurEnabled = v) } } }
            item { Slide("Blur radius ${s.dockBlurRadiusDp.toInt()}dp", s.dockBlurRadiusDp, 0f..30f, 0) { v -> change { it.copy(dockBlurRadiusDp = v) } } }
            item { Slide("Opacity ${(s.dockOpacity * 100).toInt()}%", s.dockOpacity, 0f..1f, 0) { v -> change { it.copy(dockOpacity = v) } } }
            item { Sw("Recent apps", s.showRecents) { v -> change { it.copy(showRecents = v) } } }
            item { Slide("Max recents ${s.maxRecents}", s.maxRecents.toFloat(), 1f..4f, 2) { v -> change { it.copy(maxRecents = v.toInt()) } } }
            item { Sw("Floating dock (off = edge-to-edge)", s.dockMode == DockMode.Floating) { v ->
                change { it.copy(dockMode = if (v) DockMode.Floating else DockMode.EdgeToEdge) } } }
            item { Head("Gestures") }
            item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SwipeUpAction.values().forEach { a -> FilterChip(s.swipeUp == a, { change { it.copy(swipeUp = a) } }, { Text("Swipe up: ${a.name}") }) } } }
            item { Sw("Parallax wallpaper", s.parallax) { v -> change { it.copy(parallax = v) } } }
        }
    }
}

@Composable private fun Head(t: String) = Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
@Composable private fun Slide(label: String, v: Float, r: ClosedFloatingPointRange<Float>, steps: Int, on: (Float) -> Unit) {
    Column { Text(label); Slider(v, on, valueRange = r, steps = steps) }
}
@Composable private fun Sw(label: String, v: Boolean, on: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text(label); Switch(v, on) }
