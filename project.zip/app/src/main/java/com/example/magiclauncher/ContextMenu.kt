package com.example.magiclauncher

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private data class Entry(val label: String, val icon: androidx.compose.ui.graphics.ImageBitmap? = null, val onClick: () -> Unit)

@Composable
fun ContextMenuLayer(menu: MenuState, vm: LauncherViewModel, item: HomeItem?, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val screenH = with(density) { LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val screenW = with(density) { LocalConfiguration.current.screenWidthDp.dp.toPx() }
    val menuW = with(density) { 260.dp.toPx() }
    var h by remember { mutableIntStateOf(0) }

    val shortcuts by produceState(emptyList<android.content.pm.ShortcutInfo>(), menu.ref) {
        value = menu.ref?.let { r -> withContext(Dispatchers.IO) { vm.shortcuts(r) } } ?: emptyList()
    }
    val entries = buildList {
        shortcuts.forEach { sc ->
            val ic = runCatching { vm.getApplication<android.app.Application>().getSystemService(android.content.pm.LauncherApps::class.java)
                .getShortcutIconDrawable(sc, 0)?.toBitmap(48, 48)?.asImageBitmap() }.getOrNull()
            add(Entry((sc.shortLabel ?: "").toString(), ic) { vm.startShortcut(sc); onDismiss() })
        }
        menu.ref?.let { r ->
            add(Entry("App info") {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${r.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); onDismiss()
            })
            add(Entry("Uninstall") {
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${r.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); onDismiss()
            })
        }
        if (item is HomeItem.App) add(Entry("Make Big folder") { vm.makeFolder(item.id); onDismiss() })
        if (item is HomeItem.Folder) FolderStyle.values().forEach { st ->
            add(Entry(when (st) { FolderStyle.Standard -> "Standard (1×1)"; FolderStyle.Big -> "Big (2×2)"; FolderStyle.Wide -> "Wide (2×1)" }) {
                vm.setFolderStyle(item.id, st); onDismiss() })
        }
        if (item != null) add(Entry("Remove from home") { vm.remove(item.id); onDismiss() })
        add(Entry("Edit home screen") { vm.editMode.value = true; onDismiss() })
        add(Entry("Launcher settings") { vm.settingsOpen.value = true; onDismiss() })
    }

    val scale = remember(menu) { Animatable(0.6f) }
    LaunchedEffect(menu) { scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) }  // subtle bounce

    Box(Modifier.fillMaxSize().background(Color.Black.copy(0.45f)).noRippleClickable(onDismiss)) {     // back-layer dimming
        val below = menu.rect.bottom + 12 + h < screenH
        val x = (menu.rect.center.x - menuW / 2).coerceIn(16f, screenW - menuW - 16f)
        val y = if (below) menu.rect.bottom + 12 else (menu.rect.top - 12 - h).coerceAtLeast(16f)
        Column(
            Modifier.offset { IntOffset(x.roundToInt(), y.roundToInt()) }.width(260.dp).onSizeChanged { h = it.height }
                .graphicsLayer { scaleX = scale.value; scaleY = scale.value; alpha = scale.value.coerceIn(0f, 1f)
                    transformOrigin = TransformOrigin(0.5f, if (below) 0f else 1f) }
                .clip(RoundedCornerShape(24.dp)).background(Color(0xF0202024)).padding(vertical = 8.dp)
        ) {
            entries.forEach { e ->
                Row(Modifier.fillMaxWidth().clickable(onClick = e.onClick).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    e.icon?.let { Image(it, null, Modifier.size(22.dp)); Spacer(Modifier.width(12.dp)) }
                    Text(e.label, color = Color.White, fontSize = 15.sp)
                }
            }
        }
    }
}
