package com.example.magiclauncher

import android.graphics.Bitmap
import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** Pre-API-31 fallback: heavy down/up-scale gives a cheap blur. */
private fun ImageBitmap.fakeBlur(): ImageBitmap {
    val src = asAndroidBitmap()
    val small = Bitmap.createScaledBitmap(src, (src.width / 16).coerceAtLeast(1), (src.height / 16).coerceAtLeast(1), true)
    return Bitmap.createScaledBitmap(small, src.width, src.height, true).asImageBitmap()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DynamicDock(
    pinned: List<AppRef>, recents: List<AppRef>, settings: LauncherSettings, wallpaper: ImageBitmap?,
    onLaunch: (AppRef, Rect) -> Unit, onLongPress: (AppRef, Rect) -> Unit, modifier: Modifier = Modifier
) {
    val floating = settings.dockMode == DockMode.Floating
    val shape = if (floating) RoundedCornerShape(36.dp) else RoundedCornerShape(topStart = 36.dp, topEnd = 36.dp)
    val cfg = LocalConfiguration.current
    var origin by remember { mutableStateOf(Offset.Zero) }
    val modern = Build.VERSION.SDK_INT >= 31
    val bg = remember(wallpaper) { if (!modern) wallpaper?.fakeBlur() else wallpaper }

    Box(
        modifier.then(if (floating) Modifier.padding(bottom = 20.dp) else Modifier.fillMaxWidth())
            .animateContentSize(spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow))   // flex-box style resize
            .clip(shape).onGloballyPositioned { origin = it.positionInRoot() }
    ) {
        // Glass layer: draw the wallpaper aligned to screen coords, blur it, tint it.
        Box(Modifier.matchParentSize()) {
            if (settings.dockBlurEnabled && bg != null) androidx.compose.foundation.Image(
                bg, null, contentScale = ContentScale.Crop,
                modifier = Modifier.wrapContentSize(Alignment.TopStart, unbounded = true)
                    .requiredSize(cfg.screenWidthDp.dp, cfg.screenHeightDp.dp)
                    .offset { IntOffset(-origin.x.roundToInt(), -origin.y.roundToInt()) }
                    .then(if (modern) Modifier.blur(settings.dockBlurRadiusDp.dp, BlurredEdgeTreatment.Unbounded) else Modifier)
            )
            Box(Modifier.matchParentSize().background(Color.White.copy(settings.dockOpacity)))
        }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), Arrangement.spacedBy(16.dp), Alignment.CenterVertically) {
            pinned.forEach { key(it.pkg) { DockIcon(it, settings, onLaunch, onLongPress) } }
            AnimatedVisibility(
                settings.showRecents && recents.isNotEmpty(),
                enter = expandHorizontally(spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow)) + fadeIn(),
                exit = shrinkHorizontally() + fadeOut()
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(1.dp).height(40.dp).background(Color.Black.copy(0.25f)))   // pinned | recents divider
                    recents.forEach { key(it.pkg) { DockIcon(it, settings, onLaunch, onLongPress) } }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DockIcon(ref: AppRef, s: LauncherSettings, onLaunch: (AppRef, Rect) -> Unit, onLongPress: (AppRef, Rect) -> Unit) {
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val view = LocalView.current
    AppIcon(
        ref, s, 60.dp, showLabel = false,
        modifier = Modifier.onGloballyPositioned { bounds = it.boundsInRoot() }.combinedClickable(
            onClick = { onLaunch(ref, bounds) },
            onLongClick = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onLongPress(ref, bounds) })
    )
}
