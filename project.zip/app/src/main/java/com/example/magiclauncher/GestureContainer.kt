package com.example.magiclauncher

import androidx.compose.foundation.clickable
import androidx.compose.ui.composed
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier = composed {
    clickable(indication = null, interactionSource = remember { MutableInteractionSource() }, onClick = onClick)
}

/** Swipe down / up, pinch-in, double-tap. Children (drag, pager, widgets) get events first and win conflicts. */
@Composable
fun GestureContainer(
    enabled: Boolean, onSwipeDown: () -> Unit, onSwipeUp: () -> Unit, onPinchIn: () -> Unit, onDoubleTap: () -> Unit,
    modifier: Modifier = Modifier, content: @Composable () -> Unit
) {
    val down by rememberUpdatedState(onSwipeDown); val up by rememberUpdatedState(onSwipeUp)
    val pinch by rememberUpdatedState(onPinchIn); val dbl by rememberUpdatedState(onDoubleTap)
    val on by rememberUpdatedState(enabled)
    val threshold = with(LocalDensity.current) { 96.dp.toPx() }
    Box(
        modifier
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { if (on) dbl() }) }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (on) { if (total < -threshold) up() else if (total > threshold) down() } },
                    onDragCancel = { total = 0f }
                ) { _, dy -> total += dy }
            }
            .pointerInput(Unit) {   // pinch-in, observed on the Initial pass and never consumed
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    var start = 0f; var fired = false
                    do {
                        val e = awaitPointerEvent(PointerEventPass.Initial)
                        if (e.changes.size >= 2 && !fired) {
                            val d = (e.changes[0].position - e.changes[1].position).getDistance()
                            if (start == 0f) start = d else if (d / start < 0.75f && on) { fired = true; pinch() }
                        }
                    } while (e.changes.any { it.pressed })
                }
            }
    ) { content() }
}
