package com.example.magiclauncher

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import kotlin.math.ceil

/** Standard = 2x2 preview (tap opens); Big = 2x2 icons (<=4 apps) or 3x3 (<=9); Wide = row of 4. Icons launch directly. */
@Composable
fun FolderCard(
    folder: HomeItem.Folder, settings: LauncherSettings,
    onLaunch: (AppRef, Rect) -> Unit, onOpen: () -> Unit, modifier: Modifier = Modifier
) {
    val standard = folder.style == FolderStyle.Standard
    val small = folder.apps.size <= 4
    val cols = when (folder.style) { FolderStyle.Standard -> 2; FolderStyle.Big -> if (small) 2 else 3; FolderStyle.Wide -> 4 }
    val maxVisible = when (folder.style) { FolderStyle.Standard -> 4; FolderStyle.Big -> if (small) 4 else 9; FolderStyle.Wide -> 4 }
    val rows = ceil(maxVisible / cols.toFloat()).toInt()
    val overflow = folder.apps.size > maxVisible
    val visible = if (overflow) folder.apps.take(maxVisible - 1) else folder.apps
    val extra = folder.apps.size - visible.size
    val shape = RoundedCornerShape(28.dp)

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        BoxWithConstraints(
            Modifier.weight(1f).fillMaxWidth().clip(shape).background(Color.White.copy(0.35f))
                .border(1.dp, Color.White.copy(0.45f), shape)
                .then(if (standard) Modifier.clickable(onClick = onOpen) else Modifier)
        ) {
            val pad = 10.dp
            val slotW = (maxWidth - pad * 2) / cols; val slotH = (maxHeight - pad * 2) / rows
            val icon = min(slotW, slotH) * 0.78f
            Column(Modifier.padding(pad)) {
                for (r in 0 until rows) Row {
                    for (c in 0 until cols) {
                        val idx = r * cols + c
                        Box(Modifier.size(slotW, slotH), Alignment.Center) {
                            when {
                                idx < visible.size -> FolderSlot(visible[idx], icon, settings, !standard, onLaunch)
                                overflow && idx == maxVisible - 1 -> Box(
                                    Modifier.size(icon).clip(CircleShape).background(Color.White.copy(0.4f)).clickable(onClick = onOpen),
                                    Alignment.Center
                                ) { Text("+$extra", color = Color.White, fontSize = 12.sp) }
                            }
                        }
                    }
                }
            }
        }
        if (settings.showLabels) Text(folder.name, color = LocalLabelColor.current, fontSize = 11.sp, maxLines = 1,
            modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun FolderSlot(ref: AppRef, size: Dp, s: LauncherSettings, launchable: Boolean, onLaunch: (AppRef, Rect) -> Unit) {
    var bounds by remember { mutableStateOf(Rect.Zero) }
    AppIcon(
        ref, s, size, showLabel = false,
        modifier = Modifier.onGloballyPositioned { bounds = it.boundsInRoot() }
            .then(if (launchable) Modifier.clickable { onLaunch(ref, bounds) } else Modifier)
    )
}

/** Full-screen overlay (home content behind is blurred by HomeScreen). */
@Composable
fun FolderOverlay(
    folder: HomeItem.Folder, settings: LauncherSettings,
    onLaunch: (AppRef, Rect) -> Unit, onDismiss: () -> Unit
) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessLow)) }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(0.35f * p.value.coerceIn(0f, 1f))).noRippleClickable(onDismiss), Alignment.Center) {
        Column(
            Modifier.fillMaxWidth(0.55f)
                .graphicsLayer { scaleX = 0.8f + 0.2f * p.value; scaleY = scaleX; alpha = p.value.coerceIn(0f, 1f) }
                .clip(RoundedCornerShape(36.dp)).background(Color.White.copy(0.2f)).noRippleClickable { }.padding(28.dp)
        ) {
            Text(folder.name, color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(bottom = 16.dp))
            LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.heightIn(max = 520.dp)) {
                items(folder.apps, key = { it.pkg + it.cls }) { ref ->
                    var b by remember { mutableStateOf(Rect.Zero) }
                    AppIcon(ref, settings, 64.dp, Modifier.padding(8.dp).onGloballyPositioned { b = it.boundsInRoot() }.clickable { onLaunch(ref, b) })
                }
            }
        }
    }
}
