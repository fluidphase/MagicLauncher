package com.example.magiclauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.ActivityOptions
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import android.view.View
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import kotlin.math.*

/** Dark on light wallpapers, white on dark ones (set in HomeScreen). */
val LocalLabelColor = compositionLocalOf { Color.White }

// ---------- shapes ----------
val SquircleShape: Shape = GenericShape { size, _ ->
    val a = size.width / 2; val b = size.height / 2; val steps = 72
    for (i in 0..steps) {
        val t = 2 * PI * i / steps; val c = cos(t); val s = sin(t)
        val x = a + a * sign(c) * abs(c).pow(0.5); val y = b + b * sign(s) * abs(s).pow(0.5)
        if (i == 0) moveTo(x.toFloat(), y.toFloat()) else lineTo(x.toFloat(), y.toFloat())
    }
    close()
}
fun IconShape.toShape(): Shape = when (this) {
    IconShape.Circle -> CircleShape
    IconShape.Squircle -> SquircleShape
    IconShape.Teardrop -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 12, bottomStartPercent = 50)
    IconShape.MagicRounded -> RoundedCornerShape(28)
}

// ---------- icon loading / packs ----------
object IconCache {
    private val cache = LruCache<String, ImageBitmap>(300)
    fun clear() = cache.evictAll()
    suspend fun load(ctx: Context, ref: AppRef, pack: String?): ImageBitmap = withContext(Dispatchers.IO) {
        val key = "${ref.pkg}/${ref.cls}/$pack"
        cache[key] ?: run {
            val d = IconPacks.resolve(ctx, pack, ref) ?: ctx.packageManager.getActivityIcon(ComponentName(ref.pkg, ref.cls))
            render(d).asImageBitmap().also { cache.put(key, it) }
        }
    }
    /** Draws adaptive layers un-masked so our own shape mask applies cleanly. */
    private fun render(d: Drawable, px: Int = 192): Bitmap {
        if (d !is AdaptiveIconDrawable) return d.toBitmap(px, px)
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888); val c = Canvas(bmp); val inset = (px * 0.25f).toInt()
        listOf(d.background, d.foreground).forEach { it?.setBounds(-inset, -inset, px + inset, px + inset); it?.draw(c) }
        return bmp
    }
}

object IconPacks {
    private var cachedPack: String? = null
    private var map: Map<String, String> = emptyMap()
    fun resolve(ctx: Context, pack: String?, ref: AppRef): Drawable? {
        if (pack == null) return null
        if (pack != cachedPack) { map = parse(ctx, pack); cachedPack = pack }
        val name = map["${ref.pkg}/${ref.cls}"] ?: return null
        val res = ctx.packageManager.getResourcesForApplication(pack)
        val id = res.getIdentifier(name, "drawable", pack)
        return if (id != 0) ResourcesCompat.getDrawable(res, id, null) else null
    }
    private fun parse(ctx: Context, pack: String): Map<String, String> = runCatching {
        val res = ctx.packageManager.getResourcesForApplication(pack)
        val id = res.getIdentifier("appfilter", "xml", pack); if (id == 0) return emptyMap()
        val x = res.getXml(id); val m = HashMap<String, String>()
        while (x.eventType != XmlPullParser.END_DOCUMENT) {
            if (x.eventType == XmlPullParser.START_TAG && x.name == "item") {
                val c = x.getAttributeValue(null, "component"); val d = x.getAttributeValue(null, "drawable")
                if (c != null && d != null) m[c.removePrefix("ComponentInfo{").removeSuffix("}")] = d
            }
            x.next()
        }
        m
    }.getOrDefault(emptyMap())
}

// ---------- launching (system scale-up animation from the icon's exact bounds) ----------
fun launchApp(ctx: Context, view: View, ref: AppRef, bounds: Rect?) {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(ref.pkg, ref.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    val opts = bounds?.let {
        ActivityOptions.makeScaleUpAnimation(view, it.left.toInt(), it.top.toInt(), it.width.toInt(), it.height.toInt())
    }
    runCatching { ctx.startActivity(intent, opts?.toBundle()) }
}

// ---------- composable ----------
@Composable
fun AppIcon(
    ref: AppRef, settings: LauncherSettings, iconSize: Dp, modifier: Modifier = Modifier,
    showLabel: Boolean = settings.showLabels
) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, ref, settings.iconPack) { value = IconCache.load(ctx, ref, settings.iconPack) }
    val shape = settings.iconShape.toShape(); val size = iconSize * settings.iconScale
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(size).shadow(4.dp, shape).clip(shape)) {
            bmp?.let { Image(it, ref.label, Modifier.fillMaxSize()) }
        }
        if (showLabel) {
            val c = LocalLabelColor.current
            Text(ref.label, color = c, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = if (c == Color.White) TextStyle(shadow = Shadow(Color.Black.copy(0.45f), blurRadius = 4f)) else TextStyle.Default,
                modifier = Modifier.padding(top = 4.dp))
        }
    }
}
