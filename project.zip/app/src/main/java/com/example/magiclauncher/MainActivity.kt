package com.example.magiclauncher

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import kotlin.math.ceil

class MainActivity : ComponentActivity() {
    private val vm: LauncherViewModel by viewModels()
    private lateinit var bindLauncher: ActivityResultLauncher<Intent>
    private var pending: Pair<Int, AppWidgetProviderInfo>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        bindLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            pending?.let { (id, info) -> if (r.resultCode == Activity.RESULT_OK) finishWidget(id, info) else WidgetController.host(this).deleteAppWidgetId(id) }
            pending = null
        }
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { HomeScreen(vm, ::requestWidget) } }
    }

    override fun onStart() { super.onStart(); WidgetController.host(this).startListening() }
    override fun onStop() { super.onStop(); WidgetController.host(this).stopListening() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); if (intent.action == Intent.ACTION_MAIN) vm.onHome() }

    private fun requestWidget(p: AppWidgetProviderInfo) {
        val host = WidgetController.host(this); val id = host.allocateAppWidgetId()
        if (WidgetController.manager(this).bindAppWidgetIdIfAllowed(id, p.provider)) finishWidget(id, p) else {
            pending = id to p
            bindLauncher.launch(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider))
        }
    }

    private fun finishWidget(id: Int, p: AppWidgetProviderInfo) {
        val d = resources.displayMetrics.density
        val sx = ceil(p.minWidth / d / 110f).toInt().coerceIn(1, 6); val sy = ceil(p.minHeight / d / 110f).toInt().coerceIn(1, 6)
        vm.addExternalWidget(id, sx, sy)   // widgets with a configure activity: launch host.startAppWidgetConfigureActivityForResult here
    }
}
