package com.example.magiclauncher

import android.app.Application
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.os.Process
import android.os.UserHandle
import androidx.compose.ui.geometry.Rect
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.abs

data class DragState(val id: String, val hover: Cell, val hoverSince: Long)
data class MenuState(val itemId: String?, val ref: AppRef?, val rect: Rect)

class LauncherViewModel(private val app: Application) : AndroidViewModel(app) {
    private val launcherApps = app.getSystemService(LauncherApps::class.java)

    val settings = MutableStateFlow(LauncherSettings())
    val allApps = MutableStateFlow<List<AppRef>>(emptyList())
    val items = MutableStateFlow<List<HomeItem>>(emptyList())
    val pinned = MutableStateFlow<List<AppRef>>(emptyList())
    private val recentPkgs = MutableStateFlow<List<String>>(emptyList())

    val editMode = MutableStateFlow(false)
    val drag = MutableStateFlow<DragState?>(null)
    val menu = MutableStateFlow<MenuState?>(null)
    val openFolder = MutableStateFlow<String?>(null)
    val drawerOpen = MutableStateFlow(false)
    val settingsOpen = MutableStateFlow(false)
    val pickerOpen = MutableStateFlow(false)
    val homeTick = MutableStateFlow(0)

    val recents: StateFlow<List<AppRef>> = combine(recentPkgs, allApps, pinned, settings) { pk, apps, pin, s ->
        val byPkg = apps.associateBy { it.pkg }
        pk.filter { it != app.packageName && pin.none { p -> p.pkg == it } }.mapNotNull { byPkg[it] }.take(s.maxRecents)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var snapshot: List<HomeItem> = emptyList()

    init {
        loadApps()
        launcherApps.registerCallback(object : LauncherApps.Callback() {
            override fun onPackageAdded(p: String, u: UserHandle) { loadApps() }
            override fun onPackageRemoved(p: String, u: UserHandle) { loadApps() }
            override fun onPackageChanged(p: String, u: UserHandle) { loadApps() }
            override fun onPackagesAvailable(p: Array<out String>, u: UserHandle, r: Boolean) { loadApps() }
            override fun onPackagesUnavailable(p: Array<out String>, u: UserHandle, r: Boolean) { loadApps() }
        })
        viewModelScope.launch { LauncherAccessibilityService.foreground.collect { onForeground(it) } }
    }

    fun updateSettings(f: (LauncherSettings) -> LauncherSettings) { settings.update { f(it).sanitized() }; IconCache.clear() }

    // ---------- data ----------
    fun loadApps() = viewModelScope.launch(Dispatchers.IO) {
        val list = launcherApps.getActivityList(null, Process.myUserHandle())
            .filter { it.applicationInfo.packageName != app.packageName }
            .map { AppRef(it.applicationInfo.packageName, it.componentName.className, it.label.toString()) }
            .sortedBy { it.label.lowercase() }
        allApps.value = list
        val valid = list.map { it.pkg }.toSet()
        if (items.value.isEmpty()) seed(list) else {
            items.value = items.value.filter { it !is HomeItem.App || it.ref.pkg in valid }
            pinned.value = pinned.value.filter { it.pkg in valid }
        }
    }

    /** Mirrors the reference MagicOS tablet home: clock + weather on top, folder / search / icons mid-screen. */
    private fun seed(apps: List<AppRef>) {
        pinned.value = apps.take(6)
        var list = listOf<HomeItem>(
            HomeItem.Widget(newId(), Cell(0, 1, 0), WidgetKind.Clock, spanX = 2, spanY = 1),
            HomeItem.Widget(newId(), Cell(0, 4, 0), WidgetKind.Weather, spanX = 3, spanY = 1),
            HomeItem.Widget(newId(), Cell(0, 3, 3), WidgetKind.Search, spanX = 2, spanY = 1),
            HomeItem.Folder(newId(), Cell(0, 1, 3), apps.drop(6).take(4), FolderStyle.Big, "AI Suggestions")
        )
        val slots = listOf(Cell(0, 5, 3), Cell(0, 6, 3), Cell(0, 3, 4), Cell(0, 4, 4), Cell(0, 5, 4), Cell(0, 6, 4))
        apps.drop(10).forEachIndexed { i, r ->
            val c = slots.getOrNull(i) ?: findFree(list, 1, 1, 0, Cell(0, 0, 0))
            list = list + HomeItem.App(newId(), c, r)
        }
        items.value = list
    }

    @Suppress("DEPRECATION")
    fun refreshRecents() = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val usm = app.getSystemService(UsageStatsManager::class.java); val now = System.currentTimeMillis()
            val ev = usm.queryEvents(now - 24 * 3600_000L, now); val e = UsageEvents.Event()
            val last = HashMap<String, Long>()
            while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last[e.packageName] = e.timeStamp }
            if (last.isNotEmpty()) recentPkgs.value = last.entries.sortedByDescending { it.value }.map { it.key }
        }
    }
    fun onForeground(pkg: String) = recentPkgs.update { listOf(pkg) + it.filter { p -> p != pkg } }

    // ---------- grid logic ----------
    private fun newId() = UUID.randomUUID().toString()
    private fun overlaps(a: HomeItem, c: Cell, sx: Int, sy: Int) = a.cell.page == c.page &&
        a.cell.col < c.col + sx && c.col < a.cell.col + a.spanX && a.cell.row < c.row + sy && c.row < a.cell.row + a.spanY

    private fun fits(items: List<HomeItem>, c: Cell, sx: Int, sy: Int) =
        c.col + sx <= settings.value.columns && c.row + sy <= settings.value.rows && items.none { overlaps(it, c, sx, sy) }

    fun findFree(items: List<HomeItem>, sx: Int, sy: Int, startPage: Int, near: Cell): Cell {
        val s = settings.value; val maxPage = (items.maxOfOrNull { it.cell.page } ?: 0) + 1
        for (p in startPage..maxPage) {
            var best: Cell? = null; var bd = Int.MAX_VALUE
            for (r in 0..s.rows - sy) for (c in 0..s.columns - sx) {
                val cell = Cell(p, c, r)
                if (fits(items, cell, sx, sy)) { val d = abs(c - near.col) + abs(r - near.row); if (d < bd) { bd = d; best = cell } }
            }
            if (best != null) return best
        }
        return Cell(maxPage, 0, 0)
    }

    /** Places [moving] at [target]; anything in the way slides to the nearest free cell. */
    private fun place(base: List<HomeItem>, moving: HomeItem, target: Cell): List<HomeItem> {
        val s = settings.value
        val c = Cell(target.page.coerceAtLeast(0), target.col.coerceIn(0, s.columns - moving.spanX), target.row.coerceIn(0, s.rows - moving.spanY))
        val result = mutableListOf<HomeItem>(); val displaced = mutableListOf<HomeItem>()
        base.filter { it.id != moving.id }.forEach { if (overlaps(it, c, moving.spanX, moving.spanY)) displaced += it else result += it }
        result += moving.at(c)
        displaced.forEach { d -> result += d.at(findFree(result, d.spanX, d.spanY, c.page, d.cell)) }
        return result
    }

    // ---------- drag & drop ----------
    fun beginDrag(id: String) {
        snapshot = items.value
        drag.value = DragState(id, items.value.first { it.id == id }.cell, 0L)
    }

    fun hover(c: Cell) {
        val d = drag.value ?: return; val moving = snapshot.first { it.id == d.id }
        val s = settings.value
        val cl = Cell(c.page, c.col.coerceIn(0, s.columns - moving.spanX), c.row.coerceIn(0, s.rows - moving.spanY))
        if (cl == d.hover) return
        drag.value = d.copy(hover = cl, hoverSince = System.currentTimeMillis())
        items.value = place(snapshot, moving, cl)
    }

    fun drop() {
        val d = drag.value ?: return; drag.value = null
        val moving = snapshot.firstOrNull { it.id == d.id } ?: return
        val held = System.currentTimeMillis() - d.hoverSince > 500
        val target = snapshot.firstOrNull { it.id != d.id && overlaps(it, d.hover, 1, 1) }
        val rest = snapshot.filter { it.id != moving.id && it.id != target?.id }
        val merged: HomeItem? = when {
            moving is HomeItem.Widget && target is HomeItem.Widget ->
                HomeItem.Stack(newId(), target.cell, listOf(target, moving), target.spanX, target.spanY)
            moving is HomeItem.Widget && target is HomeItem.Stack -> target.copy(widgets = target.widgets + moving)
            held && moving is HomeItem.App && target is HomeItem.App ->
                HomeItem.Folder(newId(), target.cell, listOf(target.ref, moving.ref), FolderStyle.Standard)
            held && moving is HomeItem.App && target is HomeItem.Folder -> target.copy(apps = target.apps + moving.ref)
            else -> null
        }
        if (merged != null) items.value = rest + merged
    }

    fun resizeBy(id: String, dx: Int, dy: Int) {
        val it0 = items.value.firstOrNull { it.id == id } ?: return
        val s = settings.value
        val nx = (it0.spanX + dx).coerceIn(1, s.columns - it0.cell.col); val ny = (it0.spanY + dy).coerceIn(1, s.rows - it0.cell.row)
        val u = when (it0) {
            is HomeItem.Widget -> it0.copy(spanX = nx, spanY = ny)
            is HomeItem.Stack -> it0.copy(spanX = nx, spanY = ny)
            else -> return
        }
        items.value = place(items.value, u, u.cell)
    }

    // ---------- item actions ----------
    fun setFolderStyle(id: String, style: FolderStyle) {
        val f = items.value.firstOrNull { it.id == id } as? HomeItem.Folder ?: return
        items.value = place(items.value, f.copy(style = style), f.cell)
    }
    fun makeFolder(id: String) {
        val a = items.value.firstOrNull { it.id == id } as? HomeItem.App ?: return
        val f = HomeItem.Folder(newId(), a.cell, listOf(a.ref), FolderStyle.Big)
        items.value = place(items.value.filter { it.id != id }, f, a.cell)
    }
    fun remove(id: String) { items.value = items.value.filter { it.id != id } }
    fun addBuiltIn(kind: WidgetKind) {
        val (sx, sy) = when (kind) { WidgetKind.Weather -> 3 to 1; WidgetKind.Clock, WidgetKind.Battery, WidgetKind.Storage, WidgetKind.Search -> 2 to 1; else -> 2 to 2 }
        val page = 0
        items.value = items.value + HomeItem.Widget(newId(), findFree(items.value, sx, sy, page, Cell(page, 0, 0)), kind, spanX = sx, spanY = sy)
    }
    fun addExternalWidget(appWidgetId: Int, sx: Int, sy: Int) {
        items.value = items.value + HomeItem.Widget(newId(), findFree(items.value, sx, sy, 0, Cell(0, 0, 0)), WidgetKind.External, appWidgetId, sx, sy)
    }

    // ---------- shortcuts ----------
    fun shortcuts(ref: AppRef): List<ShortcutInfo> = try {
        val q = LauncherApps.ShortcutQuery().setPackage(ref.pkg).setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
        launcherApps.getShortcuts(q, Process.myUserHandle()).orEmpty().take(5)   // needs default-home role
    } catch (e: Exception) { emptyList() }
    fun startShortcut(s: ShortcutInfo) { runCatching { launcherApps.startShortcut(s, null, null) } }

    fun closeOverlays() { openFolder.value = null; drawerOpen.value = false; settingsOpen.value = false; pickerOpen.value = false; menu.value = null }
    fun onHome() { closeOverlays(); editMode.value = false; homeTick.update { it + 1 } }
}
