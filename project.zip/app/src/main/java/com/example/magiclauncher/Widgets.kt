package com.example.magiclauncher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.*
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// ---------- AppWidgetHost plumbing ----------
object WidgetController {
    private var host: AppWidgetHost? = null
    fun host(ctx: Context): AppWidgetHost = host ?: AppWidgetHost(ctx.applicationContext, 1024).also { host = it }
    fun manager(ctx: Context): AppWidgetManager = AppWidgetManager.getInstance(ctx)
}

@Composable
fun ExternalWidget(appWidgetId: Int, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.clip(RoundedCornerShape(28.dp)),
        factory = { c ->
            val info = WidgetController.manager(c).getAppWidgetInfo(appWidgetId)
            WidgetController.host(c).createView(c, appWidgetId, info)
        },
        update = { v ->
            val d = v.resources.displayMetrics.density; val w = (v.width / d).toInt(); val h = (v.height / d).toInt()
            if (w > 0) v.updateAppWidgetSize(null, w, h, w, h)
        }
    )
}

// ---------- built-in "Magic" widgets (clock / weather are transparent like MagicOS) ----------
@Composable
fun WidgetView(w: HomeItem.Widget, modifier: Modifier = Modifier, onSearch: () -> Unit = {}) {
    when (w.kind) {
        WidgetKind.Clock -> ClockWidget(modifier)
        WidgetKind.Weather -> WeatherWidget(modifier)
        WidgetKind.Battery -> BatteryWidget(modifier)
        WidgetKind.Storage -> StorageWidget(modifier)
        WidgetKind.Search -> SearchPill(modifier, onSearch)
        WidgetKind.External -> ExternalWidget(w.appWidgetId, modifier)
    }
}

@Composable
fun ClockWidget(modifier: Modifier) {
    val now by produceState(Date()) { while (true) { value = Date(); delay(1000) } }
    val c = LocalLabelColor.current
    Column(modifier.padding(4.dp), verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.Top) {
            Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now), color = c, fontSize = 44.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.width(8.dp))
            Text(SimpleDateFormat("EEE", Locale.getDefault()).format(now), color = c, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
        }
        Text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(now), color = c.copy(0.85f), fontSize = 14.sp)
    }
}

data class Weather(val temp: String, val range: String, val days: List<Triple<String, String, String>>)
/** Plug a real provider (Open-Meteo, etc.) in here. Until then the widget shows placeholders. */
var weatherProvider: (suspend () -> Weather)? = null

private fun placeholderWeather(): Weather {
    val f = SimpleDateFormat("EEE", Locale.getDefault()); val cal = Calendar.getInstance()
    val days = (1..3).map { cal.add(Calendar.DAY_OF_YEAR, 1); Triple(f.format(cal.time), "☁", "--/--") }
    return Weather("--°", "--/--", days)
}

@Composable
fun WeatherWidget(modifier: Modifier) {
    val w by produceState(placeholderWeather()) { value = runCatching { weatherProvider?.invoke() }.getOrNull() ?: placeholderWeather() }
    val c = LocalLabelColor.current
    Row(modifier.padding(4.dp), Arrangement.spacedBy(22.dp), Alignment.CenterVertically) {
        Column {
            Text("☀  ${w.temp}", color = c, fontSize = 26.sp); Text(w.range, color = c.copy(0.8f), fontSize = 12.sp)
        }
        w.days.forEach { (d, icon, r) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(d, color = c.copy(0.8f), fontSize = 11.sp); Text(icon, color = c, fontSize = 16.sp); Text(r, color = c.copy(0.8f), fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun SearchPill(modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.clip(CircleShape).background(Color.White.copy(0.92f)).clickable(onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp)); Text("Search", color = Color(0xFF5F6368), fontSize = 14.sp)
    }
}

@Composable
private fun Glass(modifier: Modifier, content: @Composable ColumnScope.() -> Unit) =
    Column(modifier.clip(RoundedCornerShape(28.dp)).background(Color.White.copy(0.35f)).padding(16.dp), content = content)

@Composable
fun BatteryWidget(modifier: Modifier) {
    val ctx = LocalContext.current; val c = LocalLabelColor.current
    var pct by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                pct = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            }
        }
        ctx.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { r.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(r) }
    }
    Glass(modifier) {
        Text("Battery $pct%", color = c, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun StorageWidget(modifier: Modifier) {
    val c = LocalLabelColor.current
    val st = remember { StatFs(Environment.getDataDirectory().path) }
    val total = st.totalBytes; val used = total - st.availableBytes
    Glass(modifier) {
        Text("Storage ${used / 1_000_000_000}/${total / 1_000_000_000} GB", color = c, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp)); LinearProgressIndicator(progress = { used.toFloat() / total }, modifier = Modifier.fillMaxWidth())
    }
}

// ---------- swipable stack ----------
@Composable
fun WidgetStackView(s: HomeItem.Stack, modifier: Modifier = Modifier) {
    val st = rememberPagerState { s.widgets.size }
    Box(modifier) {
        VerticalPager(st, Modifier.fillMaxSize()) { WidgetView(s.widgets[it], Modifier.fillMaxSize()) }
        Column(Modifier.align(Alignment.CenterEnd).padding(end = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(s.widgets.size) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(LocalLabelColor.current.copy(if (it == st.currentPage) 0.95f else 0.4f)))
            }
        }
    }
}
