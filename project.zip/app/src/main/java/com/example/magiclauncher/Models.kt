package com.example.magiclauncher

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.dp

object Metrics { val padH = 40.dp; val padTop = 56.dp; val padBottom = 170.dp }

@Immutable data class Cell(val page: Int, val col: Int, val row: Int)
@Immutable data class AppRef(val pkg: String, val cls: String, val label: String)
enum class FolderStyle(val spanX: Int, val spanY: Int) { Standard(1, 1), Big(2, 2), Wide(2, 1) }
enum class WidgetKind { Weather, Clock, Battery, Storage, Search, External }

sealed class HomeItem {
    abstract val id: String
    abstract val cell: Cell
    abstract val spanX: Int
    abstract val spanY: Int
    abstract fun at(c: Cell): HomeItem

    data class App(override val id: String, override val cell: Cell, val ref: AppRef) : HomeItem() {
        override val spanX get() = 1
        override val spanY get() = 1
        override fun at(c: Cell) = copy(cell = c)
    }
    data class Folder(
        override val id: String, override val cell: Cell, val apps: List<AppRef>,
        val style: FolderStyle = FolderStyle.Big, val name: String = "Folder"
    ) : HomeItem() {
        override val spanX get() = style.spanX
        override val spanY get() = style.spanY
        override fun at(c: Cell) = copy(cell = c)
    }
    data class Widget(
        override val id: String, override val cell: Cell, val kind: WidgetKind, val appWidgetId: Int = -1,
        override val spanX: Int = 2, override val spanY: Int = 2
    ) : HomeItem() { override fun at(c: Cell) = copy(cell = c) }
    data class Stack(
        override val id: String, override val cell: Cell, val widgets: List<Widget>,
        override val spanX: Int, override val spanY: Int
    ) : HomeItem() { override fun at(c: Cell) = copy(cell = c) }
}

// ---------------- Settings ----------------
enum class IconShape { Circle, Squircle, Teardrop, MagicRounded }
enum class DockMode { Floating, EdgeToEdge }
enum class SwipeUpAction { AppDrawer, Search }

data class LauncherSettings(
    val columns: Int = 8, val rows: Int = 6,                 // tablet defaults
    val iconShape: IconShape = IconShape.MagicRounded,
    val iconScale: Float = 1f,                               // 0.8..1.2
    val iconPack: String? = null,
    val showLabels: Boolean = true,
    val dockBlurEnabled: Boolean = true,
    val dockBlurRadiusDp: Float = 20f,                       // 0..30
    val dockOpacity: Float = 0.35f,
    val showRecents: Boolean = true,
    val maxRecents: Int = 3,                                 // 1..4
    val dockMode: DockMode = DockMode.Floating,
    val swipeUp: SwipeUpAction = SwipeUpAction.AppDrawer,
    val parallax: Boolean = true
)

fun LauncherSettings.sanitized() = copy(
    columns = columns.coerceIn(3, 12), rows = rows.coerceIn(3, 10),
    iconScale = iconScale.coerceIn(0.8f, 1.2f), dockBlurRadiusDp = dockBlurRadiusDp.coerceIn(0f, 30f),
    maxRecents = maxRecents.coerceIn(1, 4), dockOpacity = dockOpacity.coerceIn(0f, 1f)
)

val GridPresets = listOf(4 to 5, 4 to 6, 5 to 5, 5 to 6, 6 to 5, 7 to 5, 8 to 6) // cols to rows
